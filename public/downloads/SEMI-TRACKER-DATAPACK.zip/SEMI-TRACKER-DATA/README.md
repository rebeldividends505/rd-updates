# Semiconductor Cycle Leading Indicator Dataset
## For Claude analysis — compiled May 18, 2026

## Files:
- `full-dataset.json` — All structured data: Korea exports history, stock quotes, DRAM pricing, macro context, lead/lag analysis
- `korea-semi-tracker.html` — Live tracker web page
- `01-korea-semi-vs-sox.png` — Korea exports vs SOX index chart (2022-2026)
- `02-lead-lag-correlation.png` — Lead/lag correlation analysis
- `03-scatter-exports-vs-sox.png` — Scatter: exports vs 2-month forward SOX returns
- `04-rate-of-change.png` — 2026 blow-off pattern + rate of change
- `RD-RESEARCH-BRIEFING-MAY19.md` — Full RD research briefing

## Key Data Points Today (May 18, 2026):
- Korea Semi Exports Apr flash: +182.5% YoY (blow-off)
- Micron (MU): -6.27% today (MAJOR SIGNAL)
- Samsung: -9.7% from 52-week high
- SOX: +53% above 200-day MA
- SOXL YTD: +291% but -19% last week in one session
- BTC: $76,671 (-11% YTD)
- HYPE: $45.39 (-23% from $59 ATH)

## Current Signal: 🔴 REDUCE SOXL
## Next Key Data: Korea Customs May 21 flash (~8 PM ET)
## If below +130% YoY → CUT SOXL signal

## Lead Indicators in Order of Timeliness:
1. DRAM spot prices (TrendForce, weekly)
2. Samsung/SK Hynix/Micron stock prices (daily)
3. Taiwan export flash (10th + 20th of month)
4. Korea Customs 20-day flash (21st of month)
5. Korea Customs full month (1st-2nd of month)
6. Micron quarterly earnings (guidance for coming quarter)
