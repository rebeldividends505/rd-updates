# RD TUESDAY MAY 19 — COMPLETE DATA BRIEFING
**Compiled:** Monday May 18, 2026 — 1:40 PM MDT  
**For:** Claude Code / JJ build assistant  
**Purpose:** All verifiable data for Tuesday May 19 webinar package

---

## PART 1: RD FUND STATS (Google Sheet — verified live)

| Metric | Value | Source |
|--------|-------|--------|
| Share Price (Mon close) | **$0.00190** | Google Sheet P23 |
| Day % Change | **+4.0%** | Google Sheet P24 |
| Week-over-Week Return | **+11.27%** | Google Sheet |
| Dividend Paid (May 18) | **$0.00002** (1.06% yield) | Google Sheet |
| Portfolio Value | **$14,725,500.78** | Google Sheet row 1 |
| Total Shares | **7,984,576,136** | Google Sheet |
| Bank of America Cash | **$679,165.92** | Google Sheet |
| Return Since April 2024 Pivot (Reinvestor) | **+209.5%** ($100K → $310K) | gen_pivot_chart.py |
| Return Since April 2024 Pivot (Collector) | **+93.9%** ($100K → $194K) | gen_pivot_chart.py |
| RD YTD 2026 (Reinvestor) | **+38.6%** | Calculated from monthly data |
| May 2026 MTD Return | **+13.7%** | 3 dividends: May 4 + May 12 + May 18 |
| May 2026 MTD Dividends | **$0.00006** | 3 × $0.00002 |
| Total Dividends Since 2022 | **$21,881,696+** | Year-by-year sum |
| Webinar | **Tomorrow Tue May 19, 3:30 PM ET** | |
| YouTube Embed ID | **ZA-enhqVUl4** | Same as May 12 |

---

## PART 2: LIVE CRYPTO PRICES (CoinGecko — May 18, 2026 ~1:30 PM MDT)

| Asset | Price | 24h Change | Market Cap | 24h Volume |
|-------|-------|-----------|------------|------------|
| **HYPE** | **$45.39** | -1.88% | $10.82B | $780M |
| Bitcoin (BTC) | $76,671 | -1.96% | $1.54T | $46.4B |
| Ethereum (ETH) | $2,107 | -3.72% | $254B | $19.5B |
| Solana (SOL) | $84.54 | -2.26% | $48.9B | $3.4B |

**HYPE key context:**
- ATH: **$59.37** on September 18, 2025
- Distance from ATH: **-23.5%**
- "$60 HYPE = just returning to ATH" ✅ verified

**BTC key context:**
- BTC ATH: **$126,198** (October 6, 2025)
- Distance from ATH: **-39.3%**
- BTC YTD 2026: **-10.7%** (started year ~$85K)

---

## PART 3: HYPERLIQUID PROTOCOL STATS (Live API — May 18, 2026)

| Metric | Value | Source |
|--------|-------|--------|
| Total Open Interest | **$6.06B** | HL public API |
| 24h Perpetuals Volume | **$5.78B** | HL public API |
| Total Perp Markets | **230** | HL public API |
| 30-day Volume | **$172.6B** | Research data May 17 |
| All-Time Volume | **$4.62 Trillion** | HL stats |
| All-Time Protocol Fees | **$1.24B** | CoinStats, May 2026 |
| Annual Revenue Run Rate | **$800M-$1B** | Gate.com / tokenomics.com |
| Monthly Revenue | **~$65M** | Tokenomics.com May 2026 |
| HYPE Buyback Rate | **97% of fees** | Protocol documentation |
| HYPE Tokens Burned (cumulative) | **41M+ tokens** | Research data |
| Supply Burned % | **4.17% of total supply** | Research data |
| DEX Perp Market Share | **70-80%** | CoinStats AI May 2026 |
| Total Perp Market Share (incl. CEX) | **~6%** | Buildix, edgen.tech |
| USDC on Hyperliquid | **~$5 billion** | Coinbase announcement |
| Validators active | **31** | HL API |

---

## PART 4: MACRO DATA (May 18, 2026)

| Indicator | Value | Note |
|-----------|-------|------|
| US 10Y Treasury | **4.60-4.61%** | TradingEconomics / MacroMicro |
| US 30Y Treasury | **~5.13%** | Above 5% for first time since 2007 |
| Crypto Fear & Greed | **28 (Fear)** | Alternative.me, trending down from 49 |
| F&G 7-day trend | 49→42→34→43→31→27→28 | Declining from Neutral to Fear |
| CPI YoY (April 2026) | **3.81%** | BLS April 2026 |
| CPI Jan 2026 | 2.39% | BLS (the low point) |
| CPI re-acceleration | **+142 bps in 4 months** | Jan 2.39% → Apr 3.81% |
| Core CPI (Apr) | ~2.8% | War is inflation, not core economy |
| WTI Crude | ~$80-85/bbl | Iran war premium |
| USD/JPY | ~158.73 | Yen carry trade pressure |
| Fed Funds Rate | **4.25-4.50%** | Current target range |
| Fed Chair | **Kevin Warsh** | Confirmed May 13, 54-45 Senate vote |
| First Warsh FOMC | **June 16-17, 2026** | |

---

## PART 5: EQUITY MARKET DATA (YTD 2026, as of May 18)

| Asset | YTD Return | Peak YTD | Status |
|-------|-----------|----------|--------|
| SOXL (3x Semis) | **+291%** | ~+320% | EXTREME — correcting |
| SMH (Semis ETF) | **+54%** | ~+60% | Stretched |
| NVDA | **+21%** | ~+25% | Correcting |
| QQQ | **+15%** | ~+18% | |
| SPY | **+9%** | ~+10% | |
| Gold (GLD) | **+5.29%** | **+25% (Jan 28)** | Topped, gave it back |
| Silver (SLV) | **+7.17%** | **+23% (May 8)** | Topped, gave it back |
| Energy (XLE) | **+29.7%** | ~+34% | War premium softening |
| Bitcoin (BTC) | **-10.7%** | — | Lagging = opportunity |
| RD Reinvestors (YTD) | **+38.6%** | — | Leading the field |
| RD Reinvestors (since pivot) | **+209%** | — | |

**SOX vs 200-day MA:**
- Peak gap: **+64% above 200-day** (last week) — widest since March 2000 dot-com peak
- Last session: SOX **-6%** in one session, SOXL **-19%**
- Current gap: ~+53% above 200-day (still extreme)

---

## PART 6: KEY CATALYSTS THIS WEEK (verified)

| Date | Event | Verified | Significance |
|------|-------|----------|-------------|
| May 7 | McElligott (Nomura): $2.6T gamma trap | ✅ ZeroHedge | "SMH -15% to -20% in single session" |
| May 12 | THYP (21Shares HYPE ETF) launches on Nasdaq | ✅ 21Shares IR | First US spot HYPE ETF |
| May 12 | BTC bull-bear cycle indicator turns green | ✅ On-chain | First green since March 2023 |
| May 13 | Kevin Warsh confirmed Fed Chair | ✅ Senate 54-45 | First openly pro-Bitcoin Fed Chair |
| May 14 | Coinbase becomes Hyperliquid USDC treasury deployer | ✅ Coinbase blog | AQAv2 framework, $140M+ new revenue |
| May 14 | CLARITY Act passes Senate Banking 15-9 | ✅ CryptoNews, ABA | Gallego (AZ-D) + Alsobrooks (MD-D) crossed |
| May 15 | BHYP (Bitwise HYPE ETF) launches on NYSE | ✅ Bitwise | Second spot HYPE ETF in 4 days |
| May 15 | Powell's 8-year term ends | ✅ Federal Reserve | Warsh era begins |
| Ongoing | a16z-linked wallet (0xb5E4) buying HYPE | ✅ Lookonchain/Arkham | **$90.9M total** since April 14 |

---

## PART 7: KOREA SEMICONDUCTOR EXPORT DATA (Leading SOX Indicator)

| Period | Type | Semi Export YoY | Total Export YoY | Signal |
|--------|------|----------------|-----------------|--------|
| Jun 2024 | Full | +50.4% | +5.1% | 🟢 Buy |
| Sep 2024 | Full | +51.2% | +7.5% | 🟢 Buy |
| Dec 2024 | Full | +43.1% | +6.6% | 🟡 Hold |
| Jan 2026 | Full | +82.4% | +10.3% | 🟡 Hold |
| Feb 2026 | Full | +109.7% | +10.6% | 🟡 Hold |
| Mar 2026 | Full | **+151.4%** | **+49.2%** | 🟡 Late cycle |
| Apr 1-20 | Flash ⚡ | **+182.5%** | +49.4% | 🔴 Blow-off |
| Apr 2026 | Full | **+125.9% (ICT)** | **+48.0%** | 🔴 Reduce |
| **May 1-20** | **Flash (May 21)** | **TBD** | **TBD** | **🎯 KEY DATA POINT** |

**SOXL signal from Korea data:** 🔴 REDUCE / SELL on strength
- +182% export growth = supercycle peak historically
- Rate of change decelerating (March total +49.2% → April +48%)
- SOX already started correcting before data peaked (equities lead by 3-6 months)
- **Watch May 21 flash**: Below +130% YoY = cut remaining SOXL

**Data update schedule:**
- 20-day flash: **21st of every month** (~9 AM Seoul / 8 PM ET prior evening)
- Full monthly data: **1st-2nd of each month**

---

## PART 8: DIVIDEND HISTORY (Full Year-by-Year)

| Year | Total Paid | Notes |
|------|-----------|-------|
| 2022 | $2,256,094 | Pre-pivot leveraged ETH era |
| 2023 | $4,759,384 | |
| 2024 | $6,811,005 | April 2024 pivot to spot HYPE |
| 2025 | $5,086,213 | |
| 2026 YTD | **~$2,969,000** | Through May 18 |
| **TOTAL** | **$21,881,696+** | All years combined |

**Monthly 2026 breakdown (since pivot):**
- Jan: $0.00008/share × shares
- Feb: $0.00008/share  
- Mar: $0.00010/share
- Apr: $0.00008/share
- May (so far): $0.00006/share (3 dividends: May 4 + May 12 + May 18)

---

## PART 9: REINVESTOR MATH (verified via gen_pivot_chart.py)

Starting: $100,000 at April 2024 pivot price $0.00297

| Scenario | Value | Return |
|----------|-------|--------|
| Reinvestor at $0.00190 (Mon close) | $309,524 | +209.5% |
| Collector at $0.00190 | $193,939 | +93.9% |
| Reinvestor edge over Collector | $115,585 | — |

**Position size table (for email):**
| Invested | Reinvestor Today | Collector Today |
|----------|-----------------|-----------------|
| $25,000 | ~$77,300 | ~$48,500 |
| $50,000 | ~$154,600 | ~$96,900 |
| $100,000 | ~$309,000 | ~$193,900 |
| $250,000 | ~$772,500 | ~$484,800 |

---

## PART 10: HYPERLIQUID ECOSYSTEM (May 2026)

**Top protocols by TVL on Hyperliquid L1:**
- Hyperliquid Bridge: $1.25B
- Kinetiq (kHYPE liquid staking): $819M
- HLP (derivatives vault): $388M
- HyperLend: $416M
- Morpho Blue (on HL): $311M
- Felix Vaults: $81M
- Rysk V12 (options): $59M
- Project X (DEX): $42M
- Total L1 TVL: **$3.8B+**

**Other protocols deployed:** Curve, Pendle, Euler V2, plus 130+ more

**Products live:**
- HIP-1: Spot markets (hundreds of tokens)
- HIP-2: Hyperliquidity Provider pools
- HIP-3: Single-stock perps (NVDA, AMD, S&P 500, Nasdaq-100, Apple) — live since March 2026
- HIP-4: Prediction markets — live since May 2, 2026
- HyperEVM: Full EVM-compatible smart contract layer

---

## PART 11: HYPE TARGET LADDER (from $45.39)

| HYPE Target | Timeline | % from $45.39 | RD Share Price | Significance |
|-------------|----------|--------------|----------------|--------------|
| $59.37 ATH | 90 days | +30.8% | ~$0.0025 | September 2025 ATH — already been there |
| $60 | 90 days | +32.1% | $0.00254 | Round number ATH reclaim |
| $90 | 180 days | +98.3% | $0.00381 | ~32% of Ethereum FDV |
| $180 | 1 year | +296.5% | $0.00761 | ~65% of Ethereum |
| $360 | 2 years | +693.0% | $0.01523 | Full bull cycle |

---

## PART 12: BRAND & CONTENT RULES (from SOUL.md)

**NEVER SAY:**
- "Sell gold / sell silver / sell energy" → say "trade topped" or "ran its course"  
- "The crash is coming" → say "the setup is loaded"
- "Guaranteed returns" / "Safest investment"
- "Don't miss this" / "Massive gains"
- Em dashes in SMS (use hyphens)
- Number of consecutive dividends in SMS (predates the pivot, don't specify)

**ALWAYS SAY:**
- "What we're doing with our own book"
- "The asymmetric setup"
- "Not advice for yours"
- "Through every drawdown, the dividend engine kept paying"
- "Spot exposure, no leverage, no daily reset"
- "$60 HYPE is just getting back to September 2025 ATH"

**Author:** Always Jason Cox. Dean Gallagher = CTA/closer only.
**CTA:** "Call Dean: 505-322-7515"
**Webinar link:** https://www.rebeldividends.com/startwebinar/
**Web page:** https://updates.rebeldividends.com/daily/2026-05-19/
**YouTube:** ZA-enhqVUl4 (same as last week)

---

## PART 13: KOREA SEMI TRACKER WEB PAGE
Location: https://updates.rebeldividends.com/research/korea-semi-tracker.html
Local file: ~/rd-updates-site/public/research/korea-semi-tracker.html

Auto-updates via cron on the 21st of each month when Korea Customs releases flash data.

---

## PART 14: FILE LOCATIONS

```
~/rd-updates-site/
├── outputs/2026-05-19/
│   ├── email.html          — SHORT email with link to web page
│   ├── elementor.html      — LONG web page (same as public/daily/2026-05-19/index.html)
│   ├── sms.txt             — SMS + subject line (⚠️ fill [PRICE] tomorrow AM)
│   └── companion/
│       ├── twitter-thread.txt
│       └── linkedin-post.txt
├── public/
│   ├── daily/2026-05-19/index.html    — Live at updates.rebeldividends.com/daily/2026-05-19/
│   ├── research/korea-semi-tracker.html
│   ├── charts/2026-05-19/             — 14 production charts
│   │   ├── 01-hyperliquid-hero.png
│   │   ├── 03-three-asset-comparison.png
│   │   ├── 04-monthly-dividends.png
│   │   ├── 05-annual-dividends.png
│   │   ├── 06-hype-target-ladder.png
│   │   ├── 07-gold-silver-peak-and-collapse.png
│   │   ├── 09-soxl-vs-peers-ytd.png
│   │   ├── 10-hyperliquid-market-share.png
│   │   ├── 11-hype-buyback-cumulative.png
│   │   ├── 14-validator-network.png
│   │   ├── 17-bear-case-matrix.png
│   │   ├── 18-calendar-may-june.png
│   │   ├── 20-cpi-reacceleration.png
│   │   └── reinvest-since-pivot-may19.png
│   └── downloads/
│       ├── RD-Tuesday-May19-APlus.zip  — FINAL Tuesday package
│       └── RD-May12-FINAL.zip          — Last week's reference package
```

---

## PART 15: WHAT'S STILL NEEDED FOR TUESDAY

1. ⏳ **Tuesday morning opening price** — from Google Sheet P23 (auto-pulls at 6 AM cron)
2. ⏳ **Tuesday day % change** — Google Sheet P24
3. ✅ YouTube ID: ZA-enhqVUl4 (already in the page)
4. ⏳ **Optional: $50K "tangible math" exact dividend total** — if you want the personalized dollar math box

Everything else is built, verified, and deployed.
