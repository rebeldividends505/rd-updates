# OPUS CRITIQUE BRIEF — RD Tuesday May 19, 2026 Webinar Package

**Requested by:** Jason Cox / Rebel Dividends  
**Date:** May 17, 2026  
**Current build:** v3.1 (all 5 prior audit fixes applied — see v3.1-FIX-ORDER.md)

---

## WHAT THIS PACKAGE IS

A weekly investor email for Rebel Dividends shareholders sent every Tuesday morning before a live webinar at 3:30 PM ET. Audience is ~140 non-technical investors age 40–65 who own RD shares (spot HYPE token exposure + weekly dividends). They are NOT traders — they are income investors.

**The product:** HYPE (Hyperliquid token), held spot, unleveraged. Pays weekly dividends (108 consecutive weeks). RD investor reinvestors are up ~177% since April 2024 pivot.

**The thesis in this email:**
- Big money is rotating out of AI/semis (overbought) into hard assets and crypto
- BTC decoupled from global M2 — when M2 catches up, BTC explodes and HYPE rides it
- Hyperliquid is #1 decentralized perp exchange, $180B+ monthly volume, burning supply, 97% fees back to holders
- HYPE was at $60 in Sep 2025 ATH — at ~$40 it's a buying opportunity
- 108 weekly dividends paid — tax-free capital return (IRC §301(c)(2))

---

## WHAT WE WANT FROM OPUS

### 1. Full Critique — Read as a 52-year-old RD Investor
Read the email top-to-bottom as someone who:
- Already owns RD shares (they're not being sold on the product)
- Is reading on a phone Tuesday morning before the webinar
- Has modest crypto knowledge (knows BTC, vaguely knows "Hyperliquid")
- Wants to know: should I add to my position before the webinar?

**What we want:**
- Where does conviction dip or confusion spike?
- Any claims that feel unsubstantiated or overreaching?
- Any sections that are too long, too dense, or too jargony?
- What is the single weakest moment in the email?
- What is the single strongest moment?

### 2. Data Accuracy Check
The `data/` folder contains fresh data pulled May 17. Flag any discrepancies between:
- YTD figures in the email vs data/ytd-refresh-may17.json
- HYPE/BTC prices in email vs data/crypto-prices-may17.json
- Any Hyperliquid stats (volume, fees, TVL, OI) vs data/ folder

### 3. Subject Line + SMS Review
Review the sms.txt file. Does the SMS pass the gut-check:
- Under 160 chars?
- Clear value proposition?
- Would an investor open the email after reading this?
- No em dashes (they break SMS encoding)?

### 4. One-Round Improvement Pass
After the critique, suggest the top 3 highest-impact edits. Be surgical — don't rewrite the whole thing. The v3 → v3.1 audit already resolved the major structural issues.

---

## WHAT HAS ALREADY BEEN FIXED (v3 → v3.1)
1. YTD Scoreboard reframed: "flat = setup" not "flat = disappointment"
2. Math error fixed: "3 days before webinar" → "the Friday before today's broadcast"
3. "If you have cash to deploy" DCA callout added after Jason's book position disclosure
4. "The Pitch" eyebrow → "The Case For RD Right Now"
5. "And If We're Early?" patience block added in Early Warning Dashboard

---

## CONTENT RULES (DO NOT VIOLATE)
- NOT for traders — write for investors. No jargon.
- NO technical analysis language: no support/resistance/RSI/chart patterns
- BTC and HYPE only — no Coinbase/Solana/ETH comparisons
- Always author = Jason Cox
- Dean Gallagher = CTA/closer ONLY (phone 505-322-7515)
- Every CTA links to /startwebinar/ (not /forward/, not /webinar-replay/)
- No em dashes — plain hyphens only
